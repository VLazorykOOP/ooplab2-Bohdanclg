#include <iostream>

int main(){
    int a, b, c, d;
    std::cout << "a: ";
    std::cin >> a;
    std::cout << "b: ";
    std::cin >> b;
    std::cout << "c: ";
    std::cin >> c;
    std::cout << "d: ";
    std::cin >> d;

    
    std::cout << ((a << 3) + (a << 2)) + ((((d << 4) - d) + ((b << 2) + (b << 3))) >> 10) - ((c << 2) + (c << 3)) + ((d << 4) - d) << std::endl;
    std::cout << std::endl;
  return 0;
}