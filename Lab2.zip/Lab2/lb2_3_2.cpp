#include <iostream>
#include <bitset>
#include <string>
#include <fstream>

struct charen{
    unsigned short position: 5;
    unsigned short row: 2;
    unsigned short ASCII: 8;
    unsigned short bitp: 1;
};

union chunion{
    unsigned short ch;
    charen binary;
};


int main(){
    std::ifstream inf("binary2.txt", std::ios::binary);
    std::ofstream fd("text2.txt", std::ios::binary);
    chunion a;
    char text[4][32];

    std::string encryptedCharStr;
    unsigned short encryptedChar;


    while (inf >> encryptedCharStr){
        std::bitset<16> encryptedChar(encryptedCharStr);
        a.binary.position = encryptedChar.to_ulong() & 0x1F; 
        a.binary.row = (encryptedChar.to_ulong() >> 5) & 0x03;       
        a.binary.ASCII = static_cast<char>((encryptedChar.to_ulong() >> 7) & 0xFF);

        text[a.binary.row][a.binary.position] = a.binary.ASCII;
    }


    for (int i = 0; i < 4; i++) {
        for(int j = 0; j < 32; j++){
            fd << text[i][j];
            std::cout << text[i][j];
        }
    std::cout << std::endl;
    fd << std::endl;
    }
    inf.close();
    fd.close();


    return 0;
}
