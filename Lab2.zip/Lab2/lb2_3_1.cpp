#include <iostream>
#include <bitset>
#include <string>
#include <fstream>


struct charen{
    unsigned short position: 5;
    unsigned short row: 2;
    unsigned short ASCII: 8;
    unsigned short bitp: 1;
};

union chunion{
    unsigned short ch;
    charen binary;
};

int main(){

    std::string text[4];
    for (int i = 0; i < 4; i++) {
        std::cout << "enter line " << i + 1 << ":";
        std::getline(std::cin, text[i]);
    }


    for (int i = 0; i < 4; i++) {
        while (text[i].length() < 32) {
            text[i] += ' ';
        }
    }


    std::ofstream inf("binary2.txt", std::ios::binary);
    chunion a;
    char character;
    for (int i = 0; i < 4; i++){
        for (int j = 0; j < 32; j++){
            a.ch = text[i][j];
            character = text[i][j];
            a.binary.position = j;
            a.binary.row = i;
            a.binary.ASCII = ((int)character);
            a.binary.bitp = (i & 1) ^ (j ^ 1) ^ (character ^ 1);


            std::cout << std::bitset<1>(a.binary.bitp);
            std::cout << std::bitset<8>(a.binary.ASCII);
            std::cout << std::bitset<2>(a.binary.row);
            std::cout << std::bitset<5>(a.binary.position);
            std::cout << std::endl;
            
            inf << std::bitset<1>(a.binary.bitp);
            inf << std::bitset<8>(a.binary.ASCII);
            inf << std::bitset<2>(a.binary.row);
            inf << std::bitset<5>(a.binary.position);
            inf << std::endl;
        }
    }
    inf.close();

    return 0;
}