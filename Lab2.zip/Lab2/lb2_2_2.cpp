#include <iostream>
#include <bitset>
#include <string>
#include <fstream>


int main(){

    std::ifstream inf("binary.txt", std::ios::binary);
    std::ofstream fd("text.txt", std::ios::binary);
    char text[4][32];


    std::string encryptedCharStr;
    unsigned short encryptedChar;

    int i = 0, j = 0;

    while (inf >> encryptedCharStr) {
        std::bitset<16> encryptedChar(encryptedCharStr);

        j = encryptedChar.to_ulong() & 0x1F;
        i = (encryptedChar.to_ulong() >> 5) & 0x03;
        char ch = static_cast<char>((encryptedChar.to_ulong() >> 7) & 0xFF);

        text[i][j] = ch;
    }

    for (int i = 0; i < 4; i++) {
        for(int j = 0; j < 32; j++){
            fd << text[i][j];
            std::cout << text[i][j];
        }
    std::cout << std::endl;
    fd << std::endl;
    }
    inf.close();
    fd.close();

    return 0;
}