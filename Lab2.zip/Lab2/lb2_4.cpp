/*Вводимо в консоль довільне слово. Буквам, що стоять на непраних позиціях надаємо старшу 
частину попередньої непарної букви. Для перршої непарної букви надаємо старшу частину останньої
непраної букви. Букви, що стоять на парних позиціях надаємо молодшу частину попередньої парної 
букви. Для першої парної букви надаємо основу останньої парної букви.
*/

#include <iostream>
#include <string>
#include <bitset>

int main(){

    std::string word;
    std::cout << "Enter the word: ";
    std::getline(std::cin, word);

    unsigned char ch;
    unsigned short r, t;
    for(int i = 0; i < word.length(); i++){
        r = 0;
        ch = word[i];
        r |= (int)ch;

        std::cout << std::bitset<8>(r) << std::endl;
    }

    std::cout << std::endl;

    r = 0;
    ch = word[0];
    t = ch;
    r |= t;
    if(word.length() % 2 == 0){
        t = 0;
        ch = word[word.length() - 1];
        t = ch;
        uint8_t Mch = (t & 0xF0) >> 4;
        r |= (Mch << 4);
    }
    else{
        t = 0;
        ch = word[word.length()];
        t = ch;
        uint8_t Mch = (t & 0xF0) >> 4;
        r |= (Mch << 4);
    }

    std::cout << std::bitset<8>(r) << std::endl;

    r = 0;
    ch = word[0];
    t = ch;
    r |= t;
    if(word.length() % 2 == 0){
        t = 0;
        ch = word[word.length()];
        t = ch;
        uint8_t Stch = (t >> 4) & 0x0F;
        r &= 0xF0;
        r |= Stch;
    }
    else{
        t = 0;
        ch = word[word.length() - 1];
        t = ch;
        uint8_t Stch = (t >> 4) & 0x0F;
        r &= 0xF0;
        r |= Stch;
    }

    std::cout << std::bitset<8>(r) << std::endl;

    for(int i = 2; i < word.length(); i++){
        r = 0;
        ch = word[i];
        t = ch;
        r |= t;

        if(i % 2 == 0){
            t = 0;
            ch = word[i - 2];
            t = ch;
            uint8_t Mch = (t & 0xF0) >> 4;
            r |= (Mch << 4);
        }
        if(i % 2 != 0){
            t = 0;
            ch = word[i - 2];
            t = ch;
            uint8_t Stch = (t >> 4) & 0x0F;
            r &= 0xF0;
            r |= Stch;
        }



        std::cout << std::bitset<8>(r) << std::endl;
    }

    return 0;
}
